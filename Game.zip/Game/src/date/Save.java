package date;
import java.io.PrintWriter;

import character.hero.Hero;

public class Save {

	//セーブ処理。データを保管する
	public Save(Hero hero){

	try{
		PrintWriter fw = new PrintWriter("file.txt");
		//fw.println("");
		fw.println(hero.getName());
		fw.println(hero.getJob());
		fw.println(hero.getHp());
		fw.println(hero.getSp());
		fw.println(hero.getAtk());
		fw.println(hero.getDef());
		fw.println(hero.getLevel());
		fw.println(hero.getExp());
		fw.println(hero.getExpTable());
		fw.println(hero.getLife());


		//記憶装置に保存
		fw.flush();

		//閉じる
	  fw.close();
		//BufferedWriter bu = new BufferedWriter(fw);
	}catch(Exception e){
		System.out.println("Err e="+e);
	}
}
}
