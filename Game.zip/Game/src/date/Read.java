package date;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import character.hero.Hero;

//データを読み取るクラス
public class Read {

	public Read(){}


	public Read(Hero hero,File file){

		try{
			if(ReadCheck(file)){
				//ファイルを読み込む
				FileReader read = new FileReader(file);
				BufferedReader br = new BufferedReader(read);


				//読込データをインスタンスに格納するための変数
				ArrayList<String> st = new ArrayList<String>();
				ArrayList<Integer> in = new ArrayList<Integer>();

				//読み込んだファイルを１行ずつ画面出力する
        String line;
        int count = 0;
        while ((line = br.readLine()) != null) {
        	if(count < 2){
        		st.add(line);
        	}else{
        		in.add(Integer.parseInt(line));
        	}
            count++;
          }


        //読み込んだデータを主人公のステータスにセット
        hero = new Hero(
        		st.get(0),
        		st.get(1),
        		in.get(0),
        		in.get(1),
        		in.get(2),
        		in.get(3),
        		in.get(4),
        		in.get(5),
        		in.get(6),
        		in.get(7));


        System.out.println("名前　" + hero.getName());
    		System.out.println("職業　" + hero.getJob());
    		System.out.println("HP　" + hero.getHp());
    		System.out.println("SP　" + hero.getSp());
    		System.out.println("攻撃力　" + hero.getAtk());
    		System.out.println("防御力　" + hero.getDef());
    		System.out.println("レベル　" + hero.getLevel());
    		System.out.println("取得経験値　" + hero.getExp());
    		System.out.println("経験値Table　" + hero.getExpTable());
    		System.out.println("生活力　" + hero.getLife());


    		//終了処理
        br.close();
        read.close();

			}else{
				System.out.println("データが存在しません。");
			}
		//失敗時の処理
		}catch(IOException e){
			e.printStackTrace();
		}
	}


	public boolean ReadCheck(File file){
		//ファイルが存在するか
		if (file.exists()){
			//適切なファイルか、読込可能かを判定
	    if (file.isFile() && file.canRead()){
	      return true;
	    }
	  }
		return false;
	}

}
