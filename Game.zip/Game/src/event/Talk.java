package event;

import java.util.ArrayList;


public class Talk {

	//トークイベントを格納する配列
	private ArrayList<String> talk;


	public Talk(){}


	public Talk(String name){
		talk = new ArrayList<String>();

		//0
		talk.add("いにしえのむかし　邪悪な魔物が　この世を支配した。\n"
		+ "人々が苦しみ　嘆くなか　一人の若者が立ち上がった。\n"
		+ "若者は邪悪をうちはらい　地上にふたたび平和が訪れた。\n");

		//1
		talk.add("\nそのご\n"
		+ "勇者とうたわれた若者は　名だけを残して消えてしまった。\n");

		//2
		talk.add("\n語り継がれし　勇者の名は・・・・・・" + name + "！\n");

		//3
		talk.add("\n母親「" + name +"、いつまで寝ているの。　お仕事の時間よ」\n\n"
				+ "邪悪は滅びた。しかし、人々の生活は続いていく。勇者もまたしかり。\n"
				+ "そして、人は生きていくためにお金が必要なのである。\n"
				+ name + "は生活費を稼ぐため、働かなくてはならなかった。\n\n");

		//4
		talk.add(name + "「・・・・・・行ってきます」\n");

		//5
		talk.add("\n" + name + "は仕事に出かけた！\n\n");






		//talk.add("\n");
	}






	/* 文字を1文字ずつ表示にする
	 * millis：表示速度
	 * x：表示させる文章（ArrayList）の数 */
	public void sleep(long millis,int x){

		for(int i = 0 ; i < x ; i++){
			//文字列を配列に1文字ずつセット
			String a = talk.get(i);
			char date[] = a.toCharArray();

			//配列数を取得
			int num = date.length;

			for(int j = 0 ; j < num ; j++){
				try{
					Thread.sleep(millis);
				}catch(InterruptedException e){
				}
				System.out.print(date[j]);
			}
		}

		//使用したトークイベントを削除
		for(int i = (x - 1) ; i >= 0 ; i--){
			talk.remove(i);
		}
	}



	public ArrayList<String> getTalk() {
		return talk;
	}


}
