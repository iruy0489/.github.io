package event;

public class Lottery {

	//宝くじ1等が当たる確率
	private int probability;

	//宝くじ
	private int lottery;

	//当選金額
	private int win;


	public int Win(){
		probability = new java.util.Random().nextInt(10000);
		if(probability == 0){
			lottery = 1;
			win = 100000000;
		}else if(0 <  probability && probability <= 30){
			lottery = 2;
			win = 10000000;
		}else if(30 < probability && probability <= 60){
			lottery = 3;
			win = 1000000;
		}else if(60 < probability && probability <= 300){
			lottery = 4;
			win = 100000;
		}else if(1200 < probability && probability <= 600){
			lottery = 5;
			win = 10000;
		}else{
			lottery = 6;
			win = 0;
		}

		if(lottery < 6){
			System.out.println("おめでとうございます！\n" + lottery + "等当選！　" + win + "円獲得です！！");
		}else{
			System.out.println("残念！外れです！");
		}
		return win;
	}

}
