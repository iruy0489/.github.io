package event;

import java.util.ArrayList;

public class Help {

	//ヘルプイベントを格納するリスト
	private ArrayList<String> help;

	public Help(){

		help = new ArrayList<String>();

		//0
		help.add("\nこのゲームはいつでも好きな時にクリアできます。\n"
				+ "クリア時のパターンは3つあります。\n"
				+ "1.レベルを99まで上げて魔王になる。\n"
				+ "2.お金を稼いで大富豪になり、国を作る。\n"
				+ "3.野垂れ死ぬまで生涯現役ニートを貫き通す。\n"
				+ "以上の3パターンになります。\n\n");


		//1
		help.add("\n遊び方は　1.戦う　2.働く　3.宝くじを当てる\n"
				+ "1.戦う　レベルアップし、仕事の幅が広がります。\n"
				+ "2.働く　獲得金が多くもらえます。\n"
				+ "3.宝くじをあてる　億万長者です！遊んで暮らせます！\n\n");

		//2
		help.add("\nまた、所持金を10万円貯めるごとに生活力が 1 上がります。\n"
				+ "生活力が上がると家を買ったり、結婚することが出来ます。\n"
				+ "借家で家賃を滞納すると、追い出されてしまうので注意しましょう。\n"
				+ "クリア時に所持金が少ないと、自動的にニートENDになります。\n"
				+ "それでは、平和な世界で楽しい勇者ライフをお楽しみください！\n\n");

		//help.add("\n");

	}


	/* 文字を1文字ずつ表示にする
	 * millis：表示速度
	 * x：表示させる文章（ArrayList）の数 */
	public void sleep(long millis,int x){

		for(int i = 0 ; i < x ; i++){
			String he = help.get(i);
			String[] hel = he.split("¥n");
			try{
				Thread.sleep(millis);
			}catch(InterruptedException e){
			}
			System.out.print(he);
		}


		/*使用したトークイベントを削除
		for(int i = (x - 1) ; i >= 0 ; i--){
			talk.remove(i);
		}
		*/
	}



	public ArrayList<String> getHelp() {
		return help;
	}





}
