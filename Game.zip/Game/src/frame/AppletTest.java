package frame;

import java.awt.Container;

import javax.swing.JApplet;

public class AppletTest extends JApplet {
    public void init() {
        // メインパネルを作成してフレームに追加
        MainPanel panel = new MainPanel();
        Container contentPane = getContentPane();
        contentPane.add(panel);
    }
}