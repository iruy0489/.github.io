package frame;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class MainPanel extends JPanel {
    public MainPanel() {
        // 変数などの初期化
    }

    public void paintComponent(Graphics g) {
        // 盤面を描いたり、フィールドを描いたりする
        g.setColor(Color.BLUE);
        g.fillRect(10, 10, 100, 100);
    }
}