package game;
import java.io.File;
import java.util.Scanner;

import battle.BattleStart;
import character.Money;
import character.hero.Hero;
import character.hero.HeroName;
import date.Read;
import date.Save;
import event.Help;
import event.Lottery;
import event.Talk;
import work.flower.Flower;

public class Game {
	private String name = null;
	private int AllMoney;

	Money m = new Money();
	HeroName hn = null;
	Hero hero = null;
	Talk t = null;
	BattleStart bs = new BattleStart();
	Help h = new Help();
	Flower f = new Flower();
	Lottery lo = new Lottery();





	public void GameStart(){

		while(true){


			System.out.println("ゲームを開始します。");
			System.out.println("1.はじめから　2.つづきから");
			int select = new Scanner(System.in).nextInt();


			//はじめから
			if(select == 1){
				Date(1);
			//続きから
			}else if(select == 2){
				//データの読込
				Read re = new Read();
				//ファイルの保存場所からデータを取り出す
				File file = new File("file.txt");
				boolean date = re.ReadCheck(file);

				//データが正常
				if(date == true){
					Read read = new Read(hero,file);

				//データ破損、または存在しない場合
				}else{
					System.out.println("データが存在しません。");
					System.out.println("最初から始めます。");
					Date(1);
				}
			}

			boolean game = true;
			while(game == true){
				System.out.println("なにをしますか？\n"
						+ "1.戦う　2.働く　3.宝くじを買う　4.ゲームをやめる");
				System.out.println("宝くじは300円で購入できます。");
				select = new Scanner(System.in).nextInt();

				//戦闘再開
				if(select == 1){
					bs.Start(hero);
					//所持金を合算（フィールドによって異なるため）
					m.money(bs.getAllMoney());
					System.out.println("所持金が" + m.getMoney() + "円になった！");


				//働く
				}else if(select == 2){
					f.Working();
					m.money(f.getAllMoney());
					System.out.println("所持金が" + m.getMoney() + "円になった！");


				//宝くじを買う
				}else if(select == 3){
					if(m.getMoney() >= 300){
						System.out.println("1回300円です。買いますか？\n1.はい　2.いいえ");
						select = new Scanner(System.in).nextInt();
						if(select == 1){
							m.money(-300);
							int win = lo.Win();
							m.money(win);
							System.out.println(hero.getName() + "の所持金は" + m.getMoney() + "です。");
						}else{}
					}else{
						System.out.println("お金が足りません。");
					}
				//ゲームを終了する
				}else{
					System.out.println("ゲームを終了しますか？");
					System.out.println("1はい　.2.いいえ");
					select = new Scanner(System.in).nextInt();
					if(select == 1){
						System.out.println("データを保存します。");

						//データを保存
						Save save = new Save(hero);

						System.out.println("お疲れ様でした。開始画面に戻ります。\n");
						game = false;
					}else{
						System.out.println("ゲームに戻ります。\n");
					}

				}
			}
		}






/*
			//アルファベット0-25までの配列
			char[] a = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'I', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
			int x = 26;
			for(int i = 0 ; i <= x ; i++ ){
				//System.out.print(m[i].getName() + "があらわれた！");
				for(int j = 1 ;  j > i && j <= x ; j++) {
					System.out.println(a[i]);
					System.out.println(i);
					System.out.println(j + "\n");
					i++;
				}
			}
			*/
	}

	public void Date(int select){
		hn = new HeroName();
		hero = new Hero(hn.getName());
		t = new Talk(hero.getName());
		//ストーリー開始
		t.sleep(0, 3);
		t.sleep(0, 3);

		System.out.println("まずはモンスターを倒してみよう！\nお金と経験値がもらえるよ！\n\n");

		//戦闘開始
		bs.Start(hero);
		m.money(bs.getAllMoney());
		System.out.println("所持金が" + m.getMoney() + "円になった！");
		System.out.println("お疲れ様でした！　ゲームの説明に入りますか？\n1.はい　2.いいえ");
		select = new Scanner(System.in).nextInt();

		//ゲームの説明
		if(select == 1){
			h.sleep(300,3);
		}
	}


	public void Games(){

	}

	public void Loop(){

	}


	public void Select(){
		System.out.println("");
	}


	private Scanner extracted() {
		return new java.util.Scanner(System.in);
	}

	public int getAllMoney() {
		return AllMoney;
	}

	public void setAllMoney(int allMoney) {
		AllMoney = allMoney;
	}



}
