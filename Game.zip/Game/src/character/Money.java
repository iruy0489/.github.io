package character;

public class Money {


	//所持金
	private int money = 0;

	public Money(){
		money = this.getMoney();
	}


	//獲得したお金を所持金と合計
	public void money(int dropMoney1){
		this.money = (money += dropMoney1);
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}



}
