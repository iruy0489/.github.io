package character.monster;

import character.BattleCharacter;

public class MonsterAttack extends BattleCharacter {




}
