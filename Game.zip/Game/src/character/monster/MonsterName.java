package character.monster;

public class MonsterName {

	public void Name(Monster m,int x) {

		//アルファベット0-25までの配列
		char[] a = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'I', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};


		for(int i = 0 ; i <= x ; i++ ){
			//System.out.print(m[i].getName() + "があらわれた！");
			for(int j = 1 ;  j > i && j <= x ; j++) {


				System.out.println(a[i]);
				System.out.println(i);
				System.out.println(j + "\n");


				i++;
			}
		}

	}

}
