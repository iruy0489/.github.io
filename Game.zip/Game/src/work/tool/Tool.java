package work.tool;

import item.Item;

public class Tool extends Item {

	public int Buy() {
		return 0;
	}


	public int Sell() {
		return 0;
	}


	public void Working() {
		Item[] tool = new Item[13];
/*
		 tool[0] = new Item("",,,);
		 tool[1] = new Item("",,,);
		 tool[2] = new Item("",,,);
		 tool[3] = new Item("",,,);
		 tool[4] = new Item("",,,);
		 tool[5] = new Item("",,,);
		 tool[6] = new Item("",,,);
		 tool[7] = new Item("",,,);
		 tool[8] = new Item("",,,);
		 tool[9] = new Item("",,,);
		 tool[10] = new Item("",,,);
*/


	}

}
