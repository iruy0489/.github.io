package work.weapon;

import item.Item;

public class Weapon extends Item {


	public int Buy() {
		return 0;
	}


	public int Sell() {
		return 0;
	}


	public void Working() {
		Item[] we = new Item[13];
		/*
				 we[0] = new Item("",,,);
				 we[1] = new Item("",,,);
				 we[2] = new Item("",,,);
				 we[3] = new Item("",,,);
				 we[4] = new Item("",,,);
				 we[5] = new Item("",,,);
				 we[6] = new Item("",,,);
				 we[7] = new Item("",,,);
				 we[8] = new Item("",,,);
				 we[9] = new Item("",,,);
				 we[10] = new Item("",,,);
		*/
	}

}
