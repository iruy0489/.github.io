package work.flower;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

import character.Money;
import item.Item;

public class Flower extends Item{

	//商品名
	private String name;

	//販売価格
	private int buy = 0;

	//買取価格
	private int sell = 0;

	//商品の種類
	private int category;

	//所持金を合計する変数
	int AllMoney = 0;


	//花を格納するリスト
	ArrayList<Item> flower = new ArrayList<Item>();


	Money money = new Money();

	public int Buy() {
		return 0;
	}


	public int Sell() {
		return 0;
	}


	public Flower(){}


	public void Working() {


		int select = 0;
		int price = 0;
		AllMoney = 0;
		money.setMoney(0);;


		System.out.println("花屋のバイトを始めます！\n");
		int ran = new java.util.Random().nextInt(12);
		//カテゴリーを決定し、値段を求める
		price = Talk(ran);
		//値段によってどの花を売るのか決める
		select = Select(ran);



		//キャラクターが求めている花
		Item chara = Flowers(ran);
		System.out.println(chara.getName());
		//プレイヤーが選んだ花
		Item you = flower.get(select);
		System.out.println(you.getName());

		//全く同じ花なら大成功
		if(chara.getName().equals(you.getName()) &&
			chara.getCategory() == you.getCategory() &&
			chara.getBuy() == you.getBuy()){
			System.out.println("お客さん「素敵なお花！ありがとう！これはお礼ね」\n"
				+ chara.getBuy() + "円もらった！");
			money.money(chara.getBuy());


		//値段が同じ
		}else if(chara.getBuy() == you.getBuy()){
			System.out.println("お客さん「・・・まぁ、これでもいいか。ありがとう」");

		//全く違う花
		}else{
			System.out.println("お客さん「全然違うじゃない！いらない！」\n"
					+ "お客さんは怒って帰ってしまった。");
		}
		flower.clear();
	}


	public Item Flowers(int x){
		Item[] flower = new Item[13];

		//名前、販売価格、買取価格、カテゴリー
		//1.春　2.夏　3.秋　4.冬
		flower[0] = new Item("チューリップ",100,50,0);
		flower[1] = new Item("カーネーション",200,100,0);
		flower[2] = new Item("マーガレット",300,150,0);
		flower[3] = new Item("ひまわり",100,50,1);
		flower[4] = new Item("ハイビスカス",200,100,1);
		flower[5] = new Item("プルメリア",300,150,1);
		flower[6] = new Item("コスモス",100,50,2);
		flower[7] = new Item("なでしこ",200,100,2);
		flower[8] = new Item("ダリア",300,150,2);
		flower[9] = new Item("スノウドロップ",100,50,3);
		flower[10] = new Item("りんどう",200,100,3);
		flower[11] = new Item("クリスマスローズ",300,100,3);
		//flower[12] = new Item("青いバラ",1000,500,4);

		return flower[x];
	}


	//花の種類を決める
	public int Talk(int x){

		Item it = Flowers(x);
		System.out.println(x + "：" + it.getName());
		x = it.getCategory();
		String talk;
		int p = it.getBuy();
		String a = "綺麗な";

		//乱数が4より小さいとき
			switch(x){
				case 0:
					a = "春の";
					break;

				case 1:
					a = "夏の";
					break;

				case 2:
					a = "秋の";
					break;

				case 3:
					a = "冬の";
					break;
			}
		talk = ("お客さん「お花をくださいな。\n" + a + "お花で、値段は" + p + "円くらいがいいわ」");
		System.out.println(talk);
		return p;
	}


	//どの花を売るのか決める
	public int Select(int x){
		Item it = null;
		int k = 1;
		System.out.println("どの花を売りますか？");


		//乱数を格納するList
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(x);
		it = Flowers(x);


		//重複した値を含むリスト
		for(int i = 0 ; i <= 3 ; i++){
			int ran = new java.util.Random().nextInt(12);
			a.add(ran);
		}
		System.out.println("List a = " + a);

		//重複した値を取り除く
		ArrayList<Integer> b = new ArrayList<Integer>(new HashSet<>(a));
		System.out.println("List b = " + b);


		//花のインスタンスを格納するList

		for(int i = 0 ; i < b.size() ; i++){
			it = Flowers(b.get(i));
			flower.add(it);
			System.out.println(k + "：" + flower.get(i).getName() + "　" + flower.get(i).getBuy() + "円");
			k++;
			/*
			System.out.println(b.get(i));
			flower.add(it);
			System.out.println(k + "：" + flower.get(i).getName());
			k++;
			*/
		}

		int select = new Scanner(System.in).nextInt();
		//選択肢が1始まりなので（-1）にする。配列が0開始のため。
		select = select -= 1;
		return select;
	}




	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getBuy() {
		return buy;
	}


	public void setBuy(int buy) {
		this.buy = buy;
	}


	public int getSell() {
		return sell;
	}


	public void setSell(int sell) {
		this.sell = sell;
	}


	public int getCategory() {
		return category;
	}


	public void setCategory(int category) {
		this.category = category;
	}

	public int getAllMoney() {
		AllMoney = money.getMoney();
		return AllMoney;
	}




}
