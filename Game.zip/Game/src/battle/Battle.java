package battle;

import character.BattleCharacter;

public interface Battle {


	//逃げる
	abstract boolean run(BattleCharacter c);


	//生きてる、もしくは戦闘可能な状態
	abstract boolean life(BattleCharacter c);


	//死んでる、もしくは戦闘不可能な状態
	abstract void death(BattleCharacter c);

}
