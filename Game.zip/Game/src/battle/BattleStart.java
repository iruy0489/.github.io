﻿package battle;

import java.util.ArrayList;
import java.util.Scanner;

import character.BattleCharacter;
import character.Money;
import character.hero.Hero;
import character.monster.Monster;

public class BattleStart extends BattleCharacter{

	BattleAttack ba = new BattleAttack();
	BattleSystem bs = new BattleSystem();
	Money money = new Money();

	//戦うか逃げるかを選択する変数
	int select;

	//出現モンスターの数を格納する変数
	int max;

	//乱数を格納する変数
	int x;

	//お金を格納する変数
	int getMoney = 0;
	int moneys = 0;

	//所持金を合計する変数
	int AllMoney = 0;

	//経験値を格納する変数
	int getExp = 0;
	int e = 0;;

	//主人公を生成
	Hero hero = new Hero();
	int heroHp = hero.getHp();

	//モンスターを格納するリストを生成
	Monster[] m = null;







	public void Start(Hero hero){

		//お金に関するすべての値をリセット
		getMoney = 0;
		moneys = 0;
		AllMoney = 0;
		money.setMoney(0);


		ArrayList<Monster> mon = new ArrayList<Monster>();

		//モンスターを生成
		Monster[] m = new Monster[4];
		//名前、体力、魔法力、攻撃力、防御力、経験値、お金
		m[0] = new Monster("キノコ",5,3,5,3,3,30);
		m[1] = new Monster("毒キノコ",7,5,7,5,6,60);
		m[2] = new Monster("プラチナキノコ",10,8,10,8,10,150);
		m[3] = new Monster("究極のキノコ",15,12,15,12,20,170);





		//主人公のレベルが5以下のとき、出現するのは弱い敵 1体（キノコかタケノコ）のみ
		if(hero.getLevel() < 5){
			x = new java.util.Random().nextInt(2);
			mon.add(m[x]);
			max = 0;
			System.out.print(mon.get(0).getName() + "　");


		//主人公のレベルが5以上のとき
		}else{
			//ランダムで1～3体の敵を出現させる
			x = new java.util.Random().nextInt(3);
			max = x;
			//生成したモンスターが1匹(x = 0)だったら
			if(x == 0){
				int y = new java.util.Random().nextInt(3);
				mon.add(m[y]);
				System.out.print(mon.get(0).getName() + "　");


			//複数体(x > 0)だったら
			}else{
				// x の数だけモンスターをランダムに生成
				for(int i = 0 ; i <= x ; i++ ){
					int y = new java.util.Random().nextInt(x);
					m[i] = m[y];
					mon.add(m[i]);
					System.out.println(mon.get(i).getName() + "　");
				}
			}
		}
		System.out.println("があらわれた！");




		//battleがtrueのとき、戦闘を繰り返す
		boolean battle = true;
		while(battle == true){

			//戦闘開始
			//主人公が戦闘可能（生存している
			if(hero.getHp() > 0){


			//戦うか逃げるを選択
			System.out.println("1.たたかう　" + "2.にげる");
			select = new Scanner(System.in).nextInt();

				//たたかう
				if(select == 1){


					//モンスターが1匹：max = 0
					if(max == 0){
						select = 0;
					}


					//モンスターが複数体：max = x
					if(max > 0){
						System.out.println("どのモンスターを攻撃しますか？");
						for(int i = 0; i <= max ; i++){
							System.out.println(i + "　" + mon.get(i).getName());
						}
						select = new Scanner(System.in).nextInt();
					}

						ba.Attack(hero, mon.get(select));

						if(mon.get(select).getHp() > 0){
							System.out.println(mon.get(select).getName() + "の残りHPは　" + mon.get(select).getHp());
						}


						//主人公の攻撃でモンスターを倒したら
						if(mon.get(select).getHp() <= 0){

							//お金、経験値を格納
							getMoney = Moneys(mon.get(select).getDropMoney());
							getExp = Exps(mon.get(select).getDropExp());
							System.out.println(mon.get(select).getName() + "を倒した！");

							//倒されたモンスターを削除
							mon.remove(select);
							max = max -= 1;


							//モンスターをすべて倒したら
							}if(max < 0){
								System.out.println("モンスターを倒した！");
								BattleEnd(hero,getMoney,getExp);
								int life = hero.getLife();
								int life2 = hero.Life(money.getMoney());
								if(life2 > life){
									System.out.println("生活力が" + life2 + "に上がりました！");
								}
								battle = false;
							}


						//モンスターからの攻撃
						for(int i = 0 ; i <= max ; i++){
							ba.Attack(mon.get(i), hero);
						}



				//にげる
				}else{
					bs.run(hero);
						//逃げる失敗
						if(bs.isRun() == true){
							//モンスターからの攻撃
							for(int i = 0 ; i <= max ; i++){
								ba.Attack(mon.get(i), hero);
							}
						//逃げる成功
						}else{
							battle = false;
						}
				}





			//主人公が倒された
			}else if(hero.getHp() <= 0){
				System.out.println(hero.getName() + "は倒れてしまった！\nGAME OVER");
				battle = false;
			}
		}
	}




	//獲得したお金を合算する
	public int Moneys(int x){
		moneys += x;
		return moneys;
	}


	//獲得した経験値を合算する
	public int Exps(int x){
		e = e += x;
		return e;
	}


	//モンスターを倒した場合の戦闘終了後の処理
	public void BattleEnd(BattleCharacter chara,int x,int y){
		// x = モンスターの落とすお金,
		// y = モンスターの落とす経験値

		System.out.print(x + "円と　");
		System.out.println(y + "の経験値を獲得！");
		//System.out.println("所持金が" + money.getMoney() + "になった！");

		//獲得金
		money.money(x);
		//獲得経験値：レベルアップするかどうかの処理
		bs.levelUp(chara, y);

	}




	public int getAllMoney() {
		AllMoney = money.getMoney();
		return AllMoney;
	}



}