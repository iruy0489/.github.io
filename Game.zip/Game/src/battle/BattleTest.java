package battle;

public class BattleTest {
/*
	//主人公のレベルが5以上のとき
	}else{
		//ランダムで1～3体の敵を出現させる
		x = new java.util.Random().nextInt(3);

		//生成したモンスターが1匹(x = 0)だったら
		if(x == 0){
			int y = new java.util.Random().nextInt(3);
			x = y;


		//複数体(x > 0)だったら
		}else{

			//モンスターの名前の重複：アルファベット0-25までの配列
			char[] a = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'I', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

			// x の数だけモンスターをランダムに生成
			for(int i = 0 ; i <= x ; i++ ){
				int r = new java.util.Random().nextInt(x);
				System.out.println(m[r] + "\n");
			}

			//重複したモンスターにcharを付与
			for(int i = 0 ; i <= x ; i++){
				int k = i++;
				if(m[i] == m[k]){
					String name = m[i].getName();
					m[i].setName(name + a[i]);
					m[k].setName(name + a[k]);
					System.out.println(m[i].getName() + "\n" + m[k].getName());
				}

			}
			*/

}
