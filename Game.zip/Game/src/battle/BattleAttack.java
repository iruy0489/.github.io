package battle;
import character.BattleCharacter;


public class BattleAttack extends BattleCharacter {


	private int damage;

	/*Target = 攻撃されるキャラクター*/


	/* 戦闘開始*/

	//通常攻撃
	/* 戦闘開始*/

	//通常攻撃
	public void Attack(BattleCharacter Attaker,BattleCharacter Target){




		//攻撃力に幅を持たせるための乱数を生成
		double x = (new java.util.Random().nextInt(10)+1)*0.02;


		//攻撃するキャラクターの攻撃力
		int atk = Attaker.getAtk();
		atk += atk*x;


		//攻撃を受けるキャラクターの防御力
		int def = Target.getDef();


		//防御力 - 攻撃力 の負の値がダメージになる(攻撃力の方が高い)
		damage = atk-def;


		//会心の一撃の確立を決定
		int kaishin = new java.util.Random().nextInt(30);


		//ターゲットのHP
		int hp = Target.getHp();






		/* 戦闘開始 */

			//キャラクター戦闘可能時

					//防御力のほうが高い(ダメージを受けない)とき：ノーダメージ、判定0
					if(damage <= 0){
						damage = 0;
						System.out.println(Attaker.getName() + "の攻撃！");
						System.out.println("ミス！" + Target.getName() + "はダメージを受けなかった！\n");



					//ダメージ判定あり、かつ一定確率以上の攻撃のとき
					}else if(kaishin == 30){

						//ダメージ二倍
						damage += damage;
						System.out.println(Attaker.getName() + "の攻撃！");
						System.out.println("会心の一撃！" + Target.getName() + "に" + damage + "のダメージ！\n");



					//通常のダメージ判定
					}else{
						System.out.println(Attaker.getName() + "の攻撃！");
						System.out.println(Target.getName() + "に" + damage + "のダメージ！\n");


					}


					//HPからダメージを引く
					hp = hp -= damage;

					//残りHPを返す
					Target.setHp(hp);
	}




	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}







}
