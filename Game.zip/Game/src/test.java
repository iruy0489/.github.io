import java.util.Scanner;

import battle.BattleStart;
import character.Money;
import character.hero.Hero;
import character.hero.HeroName;
import event.Help;
import event.Lottery;
import event.Talk;
import work.flower.Flower;

public class test {
	private String name = null;
	Money m = new Money();
	private int AllMoney;

	public static void main(String[] args) {



		HeroName hn = new HeroName();
		Hero hero = new Hero(hn.getName());
		Talk t = new Talk(hero.getName());
		Help h = new Help();
		Flower f = new Flower();
		Lottery lo = new Lottery();
		Money m = new Money();

		//ストーリー開始
		t.sleep(0, 3);
		t.sleep(0, 3);

		System.out.println("まずはモンスターを倒してみよう！\nお金と経験値がもらえるよ！\n\n");
		BattleStart bs = new BattleStart();

		//戦闘開始
		bs.Start(hero);
		m.money(bs.getAllMoney());
		System.out.println("所持金が" + m.getMoney() + "円になった！");
		System.out.println("お疲れ様でした！　ゲームの説明に入りますか？\n1.はい　2.いいえ");
		int select = new Scanner(System.in).nextInt();

		//ゲームの説明
		if(select == 1){
			h.sleep(300,3);
		}

		while(true){
			System.out.println("なにをしますか？\n"
					+ "1.戦う　2.働く　3.宝くじを買う");
			select = new Scanner(System.in).nextInt();

			//戦闘再開
			if(select == 1){
				bs.Start(hero);
				m.money(bs.getAllMoney());
				System.out.println("所持金が" + m.getMoney() + "円になった！");


			//働く
			}else if(select == 2){
				f.Working();
				m.money(f.getAllMoney());
				System.out.println("所持金が" + m.getMoney() + "円になった！");


			//宝くじを買う
			}else{
				if(m.getMoney() >= 300){
					System.out.println("1回300円です。買いますか？\n1.はい　2.いいえ");
					select = new Scanner(System.in).nextInt();
					if(select == 1){
						m.money(-300);
						int win = lo.Win();
						m.money(win);
						System.out.println(hero.getName() + "の所持金は" + m.getMoney() + "です。");
					}else{}
				}else{
					System.out.println("お金が足りません。");
				}
			}
		}






/*
			//アルファベット0-25までの配列
			char[] a = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'I', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
			int x = 26;
			for(int i = 0 ; i <= x ; i++ ){
				//System.out.print(m[i].getName() + "があらわれた！");
				for(int j = 1 ;  j > i && j <= x ; j++) {
					System.out.println(a[i]);
					System.out.println(i);
					System.out.println(j + "\n");
					i++;
				}
			}
			*/
	}

	public void Games(){

	}

	public void Loop(){

	}


	public void Select(){
		System.out.println("");
	}


	private Scanner extracted() {
		return new java.util.Scanner(System.in);
	}

	public int getAllMoney() {
		return AllMoney;
	}

	public void setAllMoney(int allMoney) {
		AllMoney = allMoney;
	}



}
