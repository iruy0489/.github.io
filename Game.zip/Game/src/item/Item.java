package item;

public class Item {


	//商品名
	private String name;

	//買値
	private int buy = 0;

	//売値
	private int sell = 0;

	//商品の種類
	private int category;

	public Item(){}


//商品のステータスを決める処理
	public Item(String name,int buy,int sell,int category) {
		this.name = name;
		this.buy = buy;
		this.sell = sell;
		this.category = category;
	}





	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getBuy() {
		return buy;
	}


	public void setBuy(int buy) {
		this.buy = buy;
	}


	public int getSell() {
		return sell;
	}


	public void setSell(int sell) {
		this.sell = sell;
	}


	public int getCategory() {
		return category;
	}


	public void setCategory(int category) {
		this.category = category;
	}
}
