package item;


//使用可能なアイテム
public abstract class ItemSystem extends Item{

/*

	//アイテムの名前
	String name;

	//アイテムの購入価格
	int buyPrice;

	//アイテムの売却価格
	int sellPrice;



	//アイテムの名前、購入価格、売却価格を決める
	abstract void itemSettei(String itemName,int itemBuy,int itemSell);







	//アイテムの名前の設定
	public String getName() {
		return name;
	}


	//アイテムの名前を呼び出し先に渡す
	public void setName(String name) {
		this.name = name;
	}



	//アイテムの購入価格の設定
	public int getBuyPrice() {
		return buyPrice;
	}


	//アイテムの購入価格を呼び出し先に渡す
	public void setBuyPrice(int buyPrice) {
		this.buyPrice = buyPrice;
	}



	//アイテムの売却価格の設定
	public int getSellPrice() {
		return sellPrice;
	}


	//アイテムの売却価格を呼び出し先に渡す
	public void setSellPrice(int sellPrice) {
		this.sellPrice = sellPrice;
	}
*/






}
