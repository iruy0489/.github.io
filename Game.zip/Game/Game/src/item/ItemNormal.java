package item;
import character.Money;



//一般アイテムの設定
public class ItemNormal extends ItemSystem {


	Money m = new Money();

	//アイテムの名前、購入価格、売却価格を設定
	public void itemSettei(String itemName, int itemBuy, int itemSell) {
		this.name = itemName;
		this.buyPrice = itemBuy;
		this.sellPrice = itemSell;
	}




	//アイテムを買う
	public void Buy(ItemNormal i) {

		//所持金
		int money = m.getMoney();

		//アイテムの購入価格
		int buy = i.getBuyPrice();


		//購入可能なとき、所持金から購入金額を引く
		if(money >= buy){
		money = (money -= buy);
		m.setMoney(money);


		//購入不可能(お金が足りない)ときの処理
		}else{
			System.out.println("お金が足りません");
		}
	}




	//アイテムを売る
	public void sellItem(ItemNormal i) {

		//所持金
		int money = m.getMoney();

		//アイテムの売却価格
		int sell = i.getSellPrice();


		//アイテム売却時、所持金に売却金額を足す
		money = (money += sell);
		m.setMoney(money);
	}



}
