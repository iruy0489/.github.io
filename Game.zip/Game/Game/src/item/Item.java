package item;

public interface Item {


	//アイテムの名前
	String name = null;


	//購入金額
	int buyPrice = 0;


	//売却金額
	int sellPrice = 0;;


}
