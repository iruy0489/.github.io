package game;
import battle.BattleStart;

public class Game {




	public void GameStart(){

		//戦闘開始
		BattleStart ba = new BattleStart();
		ba.Start();






	}
}
