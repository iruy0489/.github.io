package character.heroParty;

import character.BattleCharacter;



//仲間【魔法使い】の設定
public class Magic extends BattleCharacter {

	public Magic(){


		//名前
		setName("ソフィア");


		//ステータス
		Status("魔法使い",30,20,10,8,1,0,12);







	}

}
