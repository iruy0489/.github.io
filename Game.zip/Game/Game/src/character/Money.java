package character;

public class Money {


	private int money;

	public void money(int dropMoney1){
		this.money = (money += dropMoney1);
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}



}
