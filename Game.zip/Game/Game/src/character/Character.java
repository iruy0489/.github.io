package character;

public interface Character {


	//キャラクターの名前
	String name = null;


	//キャラクターの名前を設定
	void setName(String name1);


	//設定したキャラクターの名前を呼び出す
	String getName();


}
