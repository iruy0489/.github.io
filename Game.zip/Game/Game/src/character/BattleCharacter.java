package character;

public abstract class BattleCharacter implements Character {


	//名前
	String name;

	//職業
	String job;

	//ヒットポイント
	private int hp =1;

	//スキルポイント
	private int sp;

	//攻撃力
	private int atk = 1;

	//防御力
	private int def;

	//レベル
	private int level = 1;

	//獲得したお金
	private int money;

	//獲得経験値
	private int exp = 0;

	//レベルアップに必要な経験値
	private int expTable = 10;

	//キャラクターが生存しているとき
	private boolean life;

	//モンスターが落とす経験値
	private int dropExp;

	//モンスターが落とすお金
	private int dropMoney = 0;


	//ステータスに幅を出すための乱数
	public double ran = ((new java.util.Random().nextInt(10)+1)*0.02);




		/*主人公、仲間キャラクターのステータスを決定する*/
		public void Status(String job1,int hp1,int mp1,int atk1,int def1,int level1,int exp1,int expTable1){
			this.job = job1;
			this.hp = hp1 += (int)(hp1*ran);
			this.sp = mp1 += (int)(mp1*ran);
			this.atk = atk1 += (int)(atk1*ran);
			this.def = def1 += (int)(def1*ran);
			this.level = level1;
			this.exp = exp1;
			this.expTable = expTable1;
		}






		/*戦闘可能のとき
		public boolean life(){
			if(this.getHp() > 0){
				return true;
			}else{
				death();
				return false;
			}
		}
		 */








	/*各項目の設定
	 * get：呼び出し先に値を渡す
	 * set：値を設定する
	 */

	//名前
	public void setName(String name1){
		this.name = name1;
	}


	public String getName(){
		return this.name;
	}


	//職業
	public void setjob(String job1){
		this.job = job1;
	}


	public String getjob(){
		return this.job;
	}


	//ヒットポイント
	public int getHp() {
		if(this.hp > 0){
			return this.hp;
		}else{
			return 0;
		}
	}


	public void setHp(int hp) {
		if(this.hp > 0){
			this.hp = hp;
		}else{
			this.hp = 0;
		}
	}


	//スキルポイント
	public int getSp() {
		return sp;
	}


	public void setSp(int sp) {
		this.sp = sp;
	}


	//攻撃力
	public int getAtk() {
		return atk;
	}


	public void setAtk(int atk) {
		this.atk = atk;
	}


	//防御力
	public int getDef() {
		return def;
	}


	public void setDef(int def) {
		this.def = def;
	}


	//レベル
	public int getLevel() {
		return level;
	}


	public void setLevel(int level) {
		this.level = level;
	}


	//お金
	public int getMoney() {
		return money;
	}


	public void setMoney(int money) {
		this.money = money;
	}


	//累計獲得経験値
	public int getExp() {
		return exp;
	}


	public void setExp(int exp) {
		this.exp = exp;
	}


	//レベルアップに必要な経験値
	public int getExpTable() {
		return expTable;
	}


	public void setExpTable(int expTable) {
		this.expTable = expTable;
	}



	//キャラクターが生存しているとき：戦闘可能状態
	public boolean isLife() {
		return life;
	}


	public void setLife(boolean life) {
		this.life = life;
	}



	//モンスターが落とす経験値
	public int getDropExp() {
		return dropExp;
	}


	public void setDropExp(int dropExp) {
		this.dropExp = dropExp;
	}


	//モンスターが落とすお金
	public int getDropMoney() {
		return dropMoney;
	}

	public void setDropMoney(int dropMoney) {
		this.dropMoney = dropMoney;
	}




}
