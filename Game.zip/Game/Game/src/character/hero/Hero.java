package character.hero;

import character.BattleCharacter;

public class Hero extends BattleCharacter{


	//主人公の名前を決定
	HeroName hn = new HeroName();



	public Hero(){




		//名前を登録
		this.setName(hn.getName());



		//主人公のステータスを決定
		Status("勇者",50,15,10,5,10,0,10);




		//主人公のステータスチェック
		System.out.println(this.getName() + "のレベルは" + this.getLevel());
		System.out.println("HPは" + this.getHp());
		System.out.println("SPは" + this.getSp());
		System.out.println("攻撃力は" + this.getAtk());
		System.out.println("防御力は" + this.getDef() + "です。\n");

	}






}
