package character.hero;

import java.util.Scanner;


public class HeroName {

	private String name;


	//主人公の名前を設定する
	public HeroName(){

		//１回目の名前入力
		heroNameDecision();


		//x = yesかnoかの番号
		int x = extracted().nextInt();

				//名前をつけ直したいとき(残り二回変更可能
				if(x == 2){
					for(int y = 2; y >= 1 ; y--){
						if(x == 2 && y == 2){
							System.out.println("名前はあと" + y + "回入力できます");
							heroNameDecision();
						x = extracted().nextInt();
						}else if(x == 2 && y == 1){
							System.out.println("名前はあと" + y + "回入力できます");
							System.out.println("主人公の名前を入力してください");
							name = extracted().nextLine();
							decision();
						}else{
							decision();
						}
					}
				}else{
					decision();
				}
	}



	//主人公の名前を入力する部分
	public void heroNameDecision(){
		System.out.println("主人公の名前を入力してください");
		this.name = extracted().nextLine();
		System.out.println(name + "　この名前でよろしいですか？");
		String yes ="1.はい";
		String no ="2.いいえ";
		System.out.println("どちらかの番号を入力してください");
		System.out.println(yes + "　" + no);
	}



	//入力した名前に決定したことを表示
	public void decision(){
		System.out.println(this.name + "に決定しました。");
	}





	//入力した名前を呼び出すとき
	public String getName(){
		return this.name;
	}


	//名前を変更するとき
	public void setName(String heroName){
		this.name = heroName;
	}


	private Scanner extracted() {
		return new java.util.Scanner(System.in);
	}


}
