package character.monster;

import battle.BattleSystem;

public class Monster extends BattleSystem{

	//名前
	String name;

	//職業
	String job;

	//ヒットポイント
	private int hp =1;

	//スキルポイント
	private int sp;

	//攻撃力
	private int atk = 1;

	//防御力
	private int def;

	//モンスターが落とす経験値
	private int dropExp;


	//モンスターが落とすお金
	private int dropMoney = 0;



//ステータスに幅を出すための乱数
		public double ran = ((new java.util.Random().nextInt(10)+1)*0.02);







		//モンスターの名前、ステータスを決定する
		public Monster(String name1,int hp1,int sp1,int atk1,int def1,int exp1,int dropMoney1){
			this.name = name1;
			this.hp = hp1 += (int)(hp1*ran);
			this.sp = sp1 += (int)(sp1*ran);
			this.atk = atk1 += (int)(atk1*ran);
			this.def = def1 += (int)(def1*ran);
			this.dropExp = exp1;
			this.dropMoney = dropMoney1;
		}



		public Monster(){}



		public Monster(int x){

			switch(x){

				case 0:
					//モンスターを生成
					Monster[] m = new Monster[4];
					//モンスターを生成
					m[0] = new Monster("キノコ",5,3,5,3,300,3);
					m[1] = new Monster("毒キノコ",7,5,7,5,600,6);
					m[2] = new Monster("プラチナキノコ",10,8,10,8,10,15);
					m[3] = new Monster("究極のキノコ",15,12,15,12,20,17);
					break;


				case 1:
					Monster[] m1 = new Monster[4];
					m1[0] = new Monster("タケノコ",5,3,5,3,300,3);
					m1[1] = new Monster("腐ったタケノコ",7,5,7,5,600,6);
					m1[2] = new Monster("黄金タケノコ",10,8,10,8,10,15);
					m1[3] = new Monster("奇跡のタケノコ",15,12,15,12,20,17);
					break;

			}
		}





	/*各項目の設定
	 * get：呼び出し先に値を渡す
	 * set：値を設定する
	 */

	//名前
	public void setName(String name1){
		this.name = name1;
	}


	public String getName(){
		return this.name;
	}


	//職業
	public void setjob(String job1){
		this.job = job1;
	}


	public String getjob(){
		return this.job;
	}


	//ヒットポイント
	public int getHp() {
		return hp;
	}


	public void setHp(int hp) {
		this.hp = hp;
	}


	//スキルポイント
	public int getSp() {
		return sp;
	}


	public void setSp(int sp) {
		this.sp = sp;
	}


	//攻撃力
	public int getAtk() {
		return atk;
	}


	public void setAtk(int atk) {
		this.atk = atk;
	}


	//防御力
	public int getDef() {
		return def;
	}


	public void setDef(int def) {
		this.def = def;
	}


	//モンスターが落とす経験値
	public int getDropExp() {
		return dropExp;
	}


	public void setDropExp(int dropExp) {
		this.dropExp = dropExp;
	}


	//モンスターが落とすお金
	public int getDropMoney() {
		return dropMoney;
	}

	public void setDropMoney(int dropMoney) {
		this.dropMoney = dropMoney;
	}


}
