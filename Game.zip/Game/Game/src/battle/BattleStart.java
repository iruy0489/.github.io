package battle;

import java.util.Scanner;

import character.BattleCharacter;
import character.Money;
import character.hero.Hero;
import character.monster.Monster;

public class BattleStart extends BattleCharacter{

	BattleAttack ba = new BattleAttack();
	BattleSystem bs = new BattleSystem();
	Money money = new Money();

	//主人公を生成
	Hero hero = new Hero();
	int heroHp = hero.getHp();




	//モンスターを生成
	Monster[] m = new Monster[4];




	int damage = ba.getDamage();





	public void Start(){

		//モンスターを生成
		m[0] = new Monster("キノコ",5,3,5,3,300,3);
		m[1] = new Monster("タケノコ",7,5,7,5,600,6);
		m[2] = new Monster("黄金キノコ",10,8,10,8,10,15);
		m[3] = new Monster("究極のキノコ",15,12,15,12,20,17);



		//戦闘開始
		//主人公が戦闘可能（生存）
		if(hero.getHp() > 0){


			//主人公のレベルが低いとき、出現するのは弱い敵 1体（キノコかタケノコ）のみ
			if(hero.getLevel() < 5){
				int x = new java.util.Random().nextInt(2);
				System.out.println(m[x].getName() + "があらわれた！");

				//戦闘
				Battle(m[x]);





			//主人公のレベルが5以上のとき
			}else{


				//ランダムで1～3体の敵を出現させる
				int x = new java.util.Random().nextInt(3);


				//生成したモンスターが1匹(x = 0)だったら
				if(x == 0){
					int y = new java.util.Random().nextInt(3);
					System.out.println(m[y].getName() + "があらわれた！");

					//戦闘
					Battle(m[y]);




				//複数体(x > 0)だったら
				}else{

					//int z;


					// x の数だけモンスターをランダムに生成
					for(int i = 0 ; i <= x ; i++ ){
						int z = new java.util.Random().nextInt(3);
						System.out.println(i + "番目" + m[z].getName());

						if(i > 0){
							for(int j = 0; j < i ; j++){
								if(m[j].getName().equals(m[i].getName())){
									String mon = m[j].getName();
								}
							}
						}
						m[i] = m[z];
					}





				}
			}
		}
	}



/*

					System.out.println("1.たたかう　" + "2.にげる");
					int select = new Scanner(System.in).nextInt();



					//たたかう
					if(select == 1){
						System.out.println("どのモンスターを攻撃しますか？");

						//生成したモンスターの数だけ選択肢を表示
						for(i = 0 ; i <= x ; i++){
							int z = 1;
							System.out.println(z + ".　" + m[i].getName());
							z++;
						}

						int k = new Scanner(System.in).nextInt();

						ba.Attack(hero, m[k]);


						//モンスターが生きていたら主人公に攻撃
						if(chara.getHp() > 0){
							ba.Attack(chara, hero);
						//モンスターを倒していたら
						}else{
							BattleEnd(chara);
							battle = false;
						}


					//にげる
					}else{
						bs.run(hero);
							//逃げる失敗
							if(bs.isRun() == true){
								ba.Attack(chara, hero);
							//逃げる成功
							}else{
								battle = false;
							}
					}




				}
			}










			//主人公が戦闘不可能
			}else{
				System.out.println(hero.getName() + "は死んでしまった！");
				battle = false;
			}*/




	public void Battle(BattleCharacter chara){


		boolean battle = true;
		while(battle == true){
		System.out.println("1.たたかう　" + "2.にげる");
		int select = new Scanner(System.in).nextInt();

			//たたかう
			if(select == 1){

				ba.Attack(hero, chara);
				System.out.println(chara.getName() + "のHPは　" + chara.getHp());



				//モンスターが生きていたら主人公に攻撃
				if(chara.getHp() > 0){
					ba.Attack(chara, hero);


				//モンスターを倒していたら
				}else{
					System.out.println(chara.getName() + "を倒した！");
					BattleEnd(chara,chara.getDropMoney(),chara.getDropExp());
					battle = false;
				}


			//にげる
			}else{
				bs.run(hero);
					//逃げる失敗
					if(bs.isRun() == true){
						ba.Attack(chara, hero);
					//逃げる成功
					}else{
						battle = false;
					}
			}
		}
	}



	//モンスターを倒した場合の戦闘終了後の処理
	public void BattleEnd(BattleCharacter chara,int x,int y){
		// x = モンスターの落とすお金,
		// y = モンスターの落とす経験値

		System.out.print(chara.getDropMoney() + "円と　");
		System.out.println(chara.getDropExp() + "の経験値を獲得！");

		//獲得金
		money.money(x);
		//獲得経験値：レベルアップするかどうかの処理
		bs.levelUp(hero, y);

	}



	public int getDamage() {
		return damage;
	}


	public void setDamage(int damage) {
		this.damage = damage;
	}

}