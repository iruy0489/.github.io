package battle;

import character.BattleCharacter;

public class BattleSystem extends BattleCharacter{


	//逃げるの成功、失敗
	private boolean run;

	//名前
	String name;

	//職業
	String job;

	//ヒットポイント
	private int hp =1;

	//スキルポイント
	private int sp;

	//攻撃力
	private int atk = 1;

	//防御力
	private int def;

	//レベル
	private int level = 1;

	//獲得したお金
	private int money;

	//獲得経験値
	private int exp = 0;

	//レベルアップに必要な経験値
	private int expTable = 10;

	//キャラクターが生存しているとき
	private boolean life;

	//モンスターが落とす経験値
	private int dropExp;

	//モンスターが落とすお金
	private int dropMoney = 0;

	//ステータスに幅を出すための乱数
	public double ran = ((new java.util.Random().nextInt(10)+1)*0.02);



	//逃げる
	public boolean run(BattleCharacter chara) {
		setName(this.getName());
		int x = new java.util.Random().nextInt(10);
			if(x < 3){
				System.out.println(chara.getName() + "は逃げ出した！");
				run = false;
			}else{
				System.out.println(chara.getName() + "は逃げだそうとした！\nしかし逃げられなかった！");
				run = true;
			}
			return run;
	}




	//レベルアップの処理
	public void levelUp(BattleCharacter chara,int expGet){
			//獲得経験値によるレベルアップ上限までレベルアップ処理を繰り返す
			while(expGet > chara.getExpTable()){
				expGet = levelUpPattern(chara,expGet);
			}
	}


	public int levelUpPattern(BattleCharacter chara,int expGet){


		//レベルアップに必要な経験値を取得
		int table = chara.getExpTable();
		expGet = (expGet -= table);



				//レベル1～49のとき
				if(chara.getLevel() < 50 && table <= expGet){

					//次のレベルアップに必要な経験値を設定(初期値：10)
					//レベル2～49までの必要経験値 = 前回の必要経験値×1.2
					chara.setExpTable((int)(table*1.2));



				//レベル50～99までの必要経験値 = 前回の必要経験値×1.4
				}else if(chara.getLevel() < 99 && table <= expGet){
					chara.setExpTable((int)(table*1.4));



				//レベル99(レベル上限)のとき：なにもしない
				}else{
					setLevel(99);
				}



				//レベルアップ
				//現在のキャラクターのレベルを取得
				int level1 = chara.getLevel();
				//レベルアップ（現在値 + 1）
				level1++;
				//経験値をセット
				chara.setLevel(level1);


				//累計獲得経験値を取得
				int exp1 = chara.getExp();
				//戦闘でモンスターから獲得した経験値と合算
				exp1 += expGet;
				//累計獲得経験値のセット
				chara.setExp(exp1);

				System.out.println(chara.getName() + "のレベルが上がった！");
				System.out.println("レベル" + chara.getLevel() + "になった！");
				StatusUp(chara);
				System.out.println("expget - table = " + expGet);
				System.out.println("次のレベルアップには" + chara.getExpTable() + "の経験値が必要です。\n");


				return expGet;
	}


	//レベルアップによるステータスの変化
	public void StatusUp(BattleCharacter chara){

		int hp = chara.getHp();
		int sp = chara.getSp();

		//HP上昇
		int x = new java.util.Random().nextInt(10)+6;
			chara.setHp(hp += x);
			System.out.println("HPが" + x + "上がった！");

		//SP上昇
		int y = new java.util.Random().nextInt(5)+5;
		chara.setSp(sp += y);
			System.out.println("SPが" + y + "上がった！\n");


		System.out.println("現在のHPは" + chara.getHp() + "　SPは" + chara.getSp() + "です");
		System.out.println("");
	}






	//戦闘不可能になったとき
	public void death(BattleCharacter chara){
		//HPがマイナスになることはないので値を0にリセット
		System.out.println(chara.getName() + "は死んでしまった！");
		remove(chara);
		setLife(false);
	}


	//キャラクターが倒されたとき
	public void remove(BattleCharacter chara) {
		chara.setHp(0);
		remove(chara);
	}










	/*各項目の設定
	 * get：呼び出し先に値を渡す
	 * set：値を設定する
	 */

	//名前
	public void setName(String name1){
		this.name = name1;
	}


	public String getName(){
		return this.name;
	}


	//職業
	public void setjob(String job1){
		this.job = job1;
	}


	public String getjob(){
		return this.job;
	}


	//ヒットポイント
	public int getHp() {
		if(this.hp > 0){
			return this.hp;
		}else{
			return 0;
		}
	}


	public void setHp(int hp) {
		if(this.hp > 0){
			this.hp = hp;
		}else{
			this.hp = 0;
		}
	}


	//スキルポイント
	public int getSp() {
		return sp;
	}


	public void setSp(int sp) {
		this.sp = sp;
	}


	//攻撃力
	public int getAtk() {
		return atk;
	}


	public void setAtk(int atk) {
		this.atk = atk;
	}


	//防御力
	public int getDef() {
		return def;
	}


	public void setDef(int def) {
		this.def = def;
	}


	//レベル
	public int getLevel() {
		return level;
	}


	public void setLevel(int level) {
		this.level = level;
	}


	//お金
	public int getMoney() {
		return money;
	}


	public void setMoney(int money) {
		this.money = money;
	}


	//累計獲得経験値
	public int getExp() {
		return exp;
	}


	public void setExp(int exp) {
		this.exp = exp;
	}


	//レベルアップに必要な経験値
	public int getExpTable() {
		return expTable;
	}


	public void setExpTable(int expTable) {
		this.expTable = expTable;
	}



	//キャラクターが生存しているとき：戦闘可能状態
	public boolean isLife() {
		return life;
	}


	public void setLife(boolean life) {
		this.life = life;
	}



	//モンスターが落とす経験値
	public int getDropExp() {
		return dropExp;
	}


	public void setDropExp(int dropExp) {
		this.dropExp = dropExp;
	}


	//モンスターが落とすお金
	public int getdropMoney() {
		return dropMoney;
	}

	public void setdropMoney(int dropMoney) {
		this.dropMoney = dropMoney;
	}



	//逃げる
	public boolean isRun() {
		return run;
	}




	public void setRun(boolean run) {
		this.run = run;
	}



}
